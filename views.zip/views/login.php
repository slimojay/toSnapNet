<?php 
include('header.php');
?>



<body>
<div class='content-wrapper login-main'>
<form action="../model/login.php" method="post"> 
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email" name='email'>
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd" name='pass'>
  </div>
  <div class="checkbox">
    <label><input type="checkbox"> Remember me</label>
  </div>
  <button type="submit" class="btn btn-success">Submit</button>
</form>
</div>