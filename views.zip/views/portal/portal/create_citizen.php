<?php 

ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
//session_start();
include('header.php'); 
include('leftnav.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $address = $_POST['add'];
    $phone = $_POST['phone'];
    $ward = $_POST['ward'];
   echo  $app->createCitizen($name, $gender, $address, $phone, $ward); 
}
?>

<div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <div class="content-header sty-one">
      <h1 class='' style='color:dodgerblue; font-style:bold; text-transform:uppercase'><?php echo "Add Entry"; ?></h1>
     <!-- <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><i class="fa fa-angle-right"></i> Dashboard</li>
      </ol>-->
    </div>

    <div style='padding:10px'>
    <form action=" " method="post"> 
  <div class="form-group">
    <label for="email">Fullname:</label>
    <input type="text" required class="form-control" id="email" name='name'>
  </div>
  <div class="form-group">
    <label for="pwd">Address:</label>
    <input type="text" required class="form-control" id="pwd" name='add'>
  </div>
  <div class="form-group">
    <label for="phone">Phone:</label>
    <input type="text" required class="form-control" id="phone" name='phone'>
  </div>

  <div class="form-group">
    <select id="gen" name='gender' class='form-control col-lg-6' style='height:40px' required>
    <option value='male'>male</option>
    <option value='female'>female</option>
    </select>
  </div>
   
  <div class="form-group">
    
    <select id="ward" name='ward' class='form-control col-lg-6' style='height:40px' required>
    <option value=''>choose category</option>
    <?php echo $app->fetchWards(); ?>
    </select>
  </div>

 <br>

  <button type="submit" class="btn btn-success" style='margin-top:20px'>Create</button>
</form>

    </div>

   </div>
    <?php include('footer.php'); ?>