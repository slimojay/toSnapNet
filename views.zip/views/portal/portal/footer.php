<?php



?>


 <footer class="main-footer col-lg-12" style='width:100%; text-align:center'>
    <div class="pull-right hidden-xs">case manager</div>
    Copyright © <?php echo date('Y'); ?> <a href='globaltandt.com.ng' target='_blank'>GLOBAL T & T SOLUTIONS</a>. All rights reserved.</footer>
</div>
<!-- ./wrapper --> 

<!-- jQuery 3 --> 
<!--<script src="dist/js/jquery.min.js"></script> -->

<!-- v4.0.0-alpha.6 --> 
<script src="dist/bootstrap/js/bootstrap.min.js"></script> 

<!-- template --> 
<script src="dist/js/niche.js"></script> 

<!-- Chartjs JavaScript --> 
<script src="dist/plugins/chartjs/chart.min.js"></script> 
<script src="dist/plugins/chartjs/chart-int.php"></script>

<!-- Chartist JavaScript --> 
<script src="dist/plugins/chartist-js/chartist.min.js"></script> 
<script src="dist/plugins/chartist-js/chartist-plugin-tooltip.js"></script> 
<script src="dist/plugins/functions/chartist-init.js"></script>
<!--<script src="dist/plugins/formwizard/jquery-steps.js"></script> -->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/jquery.validate.min.js"></script> -->

</body>
</html>