<?php 
include('header.php');
?>



<body>
<div class='content-wrapper login-main'>
<form action="../model/create_user.php" method='post'>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email" name="email">
  </div>

  <div class="form-group">
    <label for="fname">firstname:</label>
    <input type="text" class="form-control" id="fname" name="fname">
  </div>

  <div class="form-group">
    <label for="sname">surname:</label>
    <input type="text" class="form-control" id="sname" name="sname">
  </div>

  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd" name="pass">
  </div>
 
  <button type="submit" class="btn btn-success">Submit</button>
</form>
</div>